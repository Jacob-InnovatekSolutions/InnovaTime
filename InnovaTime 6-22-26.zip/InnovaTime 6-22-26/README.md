# TimeSlips — InnovaTek Solutions

A lightweight time tracking web app built with Python (Flask) + SQLite + HTML/CSS.

## Setup

1. **Install Python 3.9+** (if not already installed)

2. **Install dependencies:**
   ```
   pip install flask
   ```
   Or:
   ```
   pip install -r requirements.txt
   ```

3. **Run the app:**
   ```
   python app.py
   ```

4. **Open in browser:**
   ```
   http://localhost:5000
   ```

## Default Admin Login

- **Username:** `admin`
- **Password:** `admin123`

> ⚠️ Change this password immediately after first login via the Password menu.

## Features

- **Per-user logins** — each employee has their own account and only sees their own entries
- **Admin panel** — add/remove users, clients, and activity codes
- **Time entry form** — Client Code, Activity Code, Date, Hours, Notes
- **Dashboard** — view recent entries, monthly total hours
- **Print Slip** — filterable by date range; prints cleanly via browser print (Ctrl+P)
  - Admins can view/print slips for any employee
- **Password management** — users change their own; admins can reset any user's password

## File Structure

```
timeslips/
├── app.py              # Flask backend + all routes
├── requirements.txt
├── timeslips.db        # Created automatically on first run
├── static/
│   └── style.css
└── templates/
    ├── layout.html     # Shared nav/wrapper
    ├── login.html
    ├── dashboard.html
    ├── new_entry.html
    ├── print_slip.html
    ├── admin.html
    └── change_password.html
```

## Notes

- **No external database needed** — SQLite file is created automatically
- **Passwords stored in plaintext** — for a production environment, upgrade to hashed passwords using `werkzeug.security`
- **Print** — use browser's Ctrl+P from the Print Slip page; nav and controls are hidden automatically
