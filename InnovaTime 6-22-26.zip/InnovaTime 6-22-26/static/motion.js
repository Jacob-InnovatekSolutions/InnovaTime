/* InnovaTime motion layer
 *
 * style.css owns every animation; this file only choreographs them:
 * staggered entrances, the gliding nav pill and tab underline, count-up
 * stats, toasts, and feedback while a click or form submit waits on the
 * server. It's progressive — every page works the same without it — and
 * prefers-reduced-motion switches the flourishes off.
 */
(function () {
  'use strict';

  var root = document.documentElement;
  var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
  var samePage = root.classList.contains('is-same-page');   // set by the inline script in layout.html

  var STEP_MS = 40;         // between page sections
  var MAX_STEPS = 9;
  var FIELD_STEP_MS = 35;   // between form fields
  var ROW_STEP_MS = 20;     // between table rows
  var MAX_ROW_STEPS = 12;   // later rows share the last delay
  var CASCADE_ROWS = 40;    // keep in sync with tr:nth-child(-n+40) in style.css
  var SETTLE_MIN_MS = 1200; // longer than any one-off entrance animation

  // Keep in sync with the entrance selectors in style.css
  var REVEAL = [
    '.page > :not(div.no-print:not(.card), .stat-strip, .tab-panel, script, style)',
    '.page > div.no-print:not(.card) > *',
    '.page-sm > :not(script, style)',
    '.stat-box',
    '.tab-panel.active'
  ].join(',');

  var delays = new Map();   // element → entrance delay (ms), only during the intro
  var cascadingTables = [];
  var resets = [];          // run when a page is restored from the back/forward cache

  function make(tag, className) {
    var el = document.createElement(tag);
    el.className = className;
    el.setAttribute('aria-hidden', 'true');
    return el;
  }

  function isRendered(el) { return el.getClientRects().length > 0; }

  function isPlainClick(e) {
    return !e.defaultPrevented && e.button === 0 && !(e.metaKey || e.ctrlKey || e.shiftKey || e.altKey);
  }

  function setDelay(el, ms) {
    delays.set(el, ms);
    el.style.setProperty('--d', ms + 'ms');
  }

  function delayOf(el) {
    for (; el; el = el.parentElement) if (delays.has(el)) return delays.get(el);
    return 0;
  }

  // ── Entrance choreography ─────────────────────────────
  // Returns when the last entrance animation will have finished.
  function choreograph() {
    if (samePage || reduceMotion) return 0;
    var step = 0, end = 0;

    document.querySelectorAll(REVEAL).forEach(function (el) {
      if (!isRendered(el)) return;
      var ms = Math.min(step++, MAX_STEPS) * STEP_MS;
      setDelay(el, ms);
      end = Math.max(end, ms + 520);
    });

    document.querySelectorAll('.form-grid').forEach(function (grid) {
      if (!isRendered(grid)) return;
      var base = delayOf(grid) + 80, n = 0;
      Array.prototype.forEach.call(grid.children, function (field) {
        if (!field.classList.contains('field') || !isRendered(field)) return;
        var ms = base + n++ * FIELD_STEP_MS;
        setDelay(field, ms);
        end = Math.max(end, ms + 420);
      });
    });

    document.querySelectorAll('table').forEach(function (table) {
      var body = table.tBodies[0];
      if (!body || !isRendered(table)) return;
      var base = delayOf(table) + 120;
      for (var i = 0; i < body.rows.length && i < CASCADE_ROWS; i++) {
        var ms = base + Math.min(i, MAX_ROW_STEPS) * ROW_STEP_MS;
        body.rows[i].style.setProperty('--d', ms + 'ms');
        end = Math.max(end, ms + 420);
      }
      table.classList.add('is-cascading');
      cascadingTables.push(table);
    });

    return end;
  }

  // Once the intro has played, drop the delays so anything shown later
  // (a switched-to tab, the Project field) animates in immediately.
  function settle() {
    delays.forEach(function (_, el) { el.style.removeProperty('--d'); });
    delays.clear();
    cascadingTables.forEach(function (table) {
      table.classList.remove('is-cascading');
      Array.prototype.forEach.call(table.tBodies[0].rows, function (row) { row.style.removeProperty('--d'); });
    });
    cascadingTables = [];
    root.classList.remove('is-same-page');
  }

  // ── Count-up stats ────────────────────────────────────
  // Numbers roll up from zero on arrival, or from their previous values when
  // the same page reloads (e.g. "Recent Entries" 20 → 19 after a delete).
  var NUMBER = /^(\$?)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d+))?$/;
  var COUNT_MS = 1100;
  var counters = [];

  function parseStat(text) {
    var m = NUMBER.exec(text.trim());
    if (!m) return null;   // e.g. the "Today" date tile
    return {
      prefix: m[1],
      decimals: m[3] ? m[3].length : 0,
      commas: m[1] === '$' || m[2].indexOf(',') !== -1,
      value: parseFloat(m[2].replace(/,/g, '') + (m[3] ? '.' + m[3] : ''))
    };
  }

  function formatStat(value, spec) {
    var text = value.toFixed(spec.decimals);
    if (spec.commas) {
      var parts = text.split('.');
      parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      text = parts.join('.');
    }
    return spec.prefix + text;
  }

  function storedStats(key) {
    try { return JSON.parse(sessionStorage.getItem(key) || 'null'); } catch (e) { return null; }
  }

  function storeStats(key, values) {
    try { sessionStorage.setItem(key, JSON.stringify(values)); } catch (e) { /* private mode, quota */ }
  }

  function finishCounter(c) {
    c.el.textContent = c.text;
    c.done = true;
  }

  function tickCounters(now) {
    var running = false;
    counters.forEach(function (c) {
      if (c.done) return;
      var t = (now - c.start) / COUNT_MS;
      if (t >= 1) return finishCounter(c);
      running = true;
      if (t < 0) return;
      var eased = 1 - Math.pow(2, -10 * t);   // ease-out-expo
      c.el.textContent = formatStat(c.from + (c.spec.value - c.from) * eased, c.spec);
    });
    if (running) requestAnimationFrame(tickCounters);
  }

  function countUps() {
    var els = Array.prototype.slice.call(document.querySelectorAll('.stat-value'));
    if (!els.length) return;
    var key = 'innovatime:stats:' + location.pathname;
    var specs = els.map(function (el) { return parseStat(el.textContent); });
    var previous = samePage ? storedStats(key) : null;
    if (!previous || previous.length !== els.length) previous = null;
    storeStats(key, specs.map(function (s) { return s ? s.value : null; }));
    if (reduceMotion) return;

    var now = performance.now();
    els.forEach(function (el, i) {
      var spec = specs[i];
      if (!spec || !isRendered(el)) return;
      var from = previous ? previous[i] : (samePage ? spec.value : 0);
      if (typeof from !== 'number' || from === spec.value) return;
      counters.push({ el: el, spec: spec, from: from, text: el.textContent, start: now + delayOf(el) + 100, done: false });
      el.textContent = formatStat(from, spec);
    });
    if (counters.length) requestAnimationFrame(tickCounters);
  }

  window.addEventListener('beforeprint', function () { counters.forEach(finishCounter); });

  // ── Gliding indicators ────────────────────────────────
  function placeOver(indicator, target, animate, matchHeight) {
    if (!animate) indicator.style.transition = 'none';
    indicator.style.width = target.offsetWidth + 'px';
    if (matchHeight) indicator.style.height = target.offsetHeight + 'px';
    indicator.style.transform = 'translate(' + target.offsetLeft + 'px,' + (matchHeight ? target.offsetTop : 0) + 'px)';
    if (!animate) {
      void indicator.offsetWidth;
      indicator.style.transition = '';
    }
  }

  function whenLayoutChanges(el, fn) {
    if (window.ResizeObserver) new ResizeObserver(fn).observe(el);
    else window.addEventListener('resize', fn);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fn);
  }

  function initNav() {
    var links = document.querySelector('.nav-links');
    if (!links) return;
    var anchors = Array.prototype.slice.call(links.querySelectorAll('a'));
    var home = links.querySelector('a.active');
    var hover = make('span', 'nav-hover');
    var pill = make('span', 'nav-pill');
    var hovered = null;
    links.appendChild(hover);
    links.appendChild(pill);
    links.classList.add('has-pills');

    function rest(animate) {
      var active = links.querySelector('a.active');
      if (active) {
        placeOver(pill, active, animate, true);
        pill.classList.add('is-placed');
      } else {
        pill.classList.remove('is-placed');
      }
    }

    function showHover(a) {
      placeOver(hover, a, hover.classList.contains('is-visible'), true);
      hover.classList.add('is-visible');
      hovered = a;
    }

    function hideHover() {
      hover.classList.remove('is-visible');
      hovered = null;
    }

    anchors.forEach(function (a) {
      a.addEventListener('pointerenter', function (e) { if (e.pointerType === 'mouse') showHover(a); });
      a.addEventListener('focus', function () { if (a.matches(':focus-visible')) showHover(a); });
    });
    links.addEventListener('pointerleave', hideHover);
    links.addEventListener('focusout', function (e) { if (!links.contains(e.relatedTarget)) hideHover(); });

    // Glide the active pill to the clicked link straight away; the next page's
    // view transition carries it the rest of the way.
    links.addEventListener('click', function (e) {
      var a = e.target.closest('a');
      if (!a || !isPlainClick(e) || a.classList.contains('active')) return;
      anchors.forEach(function (x) { x.classList.toggle('active', x === a); });
      rest(true);
    });

    rest(false);
    whenLayoutChanges(links, function () {
      rest(false);
      if (hovered) placeOver(hover, hovered, false, true);
    });
    resets.push(function () {
      anchors.forEach(function (x) { x.classList.toggle('active', x === home); });
      rest(false);
      hideHover();
    });
  }

  function initTabs() {
    document.querySelectorAll('.tabs').forEach(function (tabs, i) {
      var ink = make('span', 'tab-ink');
      if (i === 0) ink.style.viewTransitionName = 'tab-ink';   // names must be unique per page
      tabs.appendChild(ink);
      tabs.classList.add('has-ink');

      function sync(animate, target) {
        target = target || tabs.querySelector('.tab.active');
        ink.style.opacity = target ? '' : '0';
        if (target) placeOver(ink, target, animate, false);
      }

      sync(false);
      // Admin switches tabs in place; Client Reports navigates — either way the ink moves on click
      tabs.addEventListener('click', function (e) {
        var tab = e.target.closest('.tab');
        if (tab) sync(true, tab);
      });
      new MutationObserver(function () { sync(true); })
        .observe(tabs, { subtree: true, attributes: true, attributeFilter: ['class'] });
      whenLayoutChanges(tabs, function () { sync(false); });
      resets.push(function () { sync(false); });
    });
  }

  function initNavShadow() {
    var nav = document.querySelector('nav');
    if (!nav) return;
    var queued = false;
    function update() {
      nav.classList.toggle('is-scrolled', window.scrollY > 4);
      queued = false;
    }
    window.addEventListener('scroll', function () {
      if (!queued) { queued = true; requestAnimationFrame(update); }
    }, { passive: true });
    update();
  }

  // ── Toasts ────────────────────────────────────────────
  function dismissToast(toast) {
    if (toast.classList.contains('is-leaving')) return;
    toast.style.height = toast.offsetHeight + 'px';
    void toast.offsetHeight;
    toast.classList.add('is-leaving');
    var removed = false;
    function remove() {
      if (removed) return;
      removed = true;
      var stack = toast.parentNode;
      toast.remove();
      if (stack && !stack.children.length) stack.remove();
    }
    toast.addEventListener('transitionend', function (e) {
      if (e.target === toast && e.propertyName === 'height') remove();
    });
    setTimeout(remove, 450);
  }

  function initToasts() {
    document.querySelectorAll('.toast').forEach(function (toast, i) {
      toast.style.setProperty('--ti', i);
      if (samePage) toast.style.setProperty('--toast-delay', (40 + i * 90) + 'ms');
      var msg = toast.querySelector('.toast-msg');
      // Longer messages stay up longer
      if (msg) toast.style.setProperty('--toast-ms', Math.min(9000, 3500 + msg.textContent.trim().length * 50) + 'ms');
      var close = toast.querySelector('.toast-close');
      if (close) close.addEventListener('click', function () { dismissToast(toast); });
      toast.addEventListener('animationend', function (e) {
        if (e.animationName === 'toast-timer') dismissToast(toast);
      });
    });
  }

  // ── Navigation feedback ───────────────────────────────
  var progress = null;
  var watchdog = 0;
  var WATCHDOG_MS = 10000;

  function startProgress() {
    if (!progress) {
      progress = make('div', 'nav-progress');
      document.body.appendChild(progress);
    }
    progress.classList.remove('is-active');
    void progress.offsetWidth;
    progress.classList.add('is-active');
    // If we're somehow still here (navigation stopped or cancelled), put the
    // page back rather than leaving rows faded out and buttons spinning.
    clearTimeout(watchdog);
    watchdog = setTimeout(resetFeedback, WATCHDOG_MS);
  }

  function resetFeedback() {
    clearTimeout(watchdog);
    document.querySelectorAll('.is-busy').forEach(function (b) {
      b.classList.remove('is-busy');
      b.removeAttribute('aria-busy');
    });
    document.querySelectorAll('tr.is-leaving').forEach(function (r) {
      r.classList.remove('is-leaving', 'is-leaving-del', 'is-leaving-ok');
    });
    if (progress) progress.classList.remove('is-active');
  }

  function initFeedback() {
    // Runs after each form's own submit handlers, so validation and
    // confirm() cancellations have already had their say.
    document.addEventListener('submit', function (e) {
      if (e.defaultPrevented) return;
      var form = e.target;
      if (form.target && form.target !== '_self') return;
      var btn = e.submitter || form.querySelector('button[type="submit"], button:not([type]), input[type="submit"]');
      if (btn && btn.classList.contains('btn')) {
        btn.classList.add('is-busy');
        btn.setAttribute('aria-busy', 'true');
      }
      var row = form.closest('tr');
      if (row && btn) {
        if (btn.classList.contains('btn-del')) row.classList.add('is-leaving', 'is-leaving-del');
        else if (btn.classList.contains('btn-green')) row.classList.add('is-leaving', 'is-leaving-ok');
      }
      startProgress();
    });

    document.addEventListener('click', function (e) {
      if (!isPlainClick(e)) return;
      var a = e.target.closest && e.target.closest('a[href]');
      if (!a || (a.target && a.target !== '_self') || a.hasAttribute('download')) return;
      var url;
      try { url = new URL(a.href, location.href); } catch (err) { return; }
      if (url.origin !== location.origin) return;
      if (url.pathname === location.pathname && url.search === location.search && url.hash) return;
      startProgress();
    });

    // Back/forward cache restores the page exactly as we left it — mid-exit
    resets.push(resetFeedback);
    window.addEventListener('pageshow', function (e) {
      if (e.persisted) resets.forEach(function (fn) { fn(); });
    });
  }

  // ── Public helpers for page scripts ───────────────────
  var closing = new WeakMap();

  function cancelClose(modal) {
    var pending = closing.get(modal);
    if (!pending) return;
    modal.removeEventListener('animationend', pending.onEnd);
    clearTimeout(pending.timer);
    closing.delete(modal);
  }

  window.Motion = {
    reduced: reduceMotion,

    // Restart a one-shot animation class, e.g. Motion.replay(input, 'shake')
    replay: function (el, className) {
      if (!el) return;
      el.classList.remove(className);
      void el.offsetWidth;
      el.classList.add(className);
      el.addEventListener('animationend', function done(e) {
        if (e.target !== el) return;
        el.classList.remove(className);
        el.removeEventListener('animationend', done);
      });
    },
    shake: function (el) { window.Motion.replay(el, 'shake'); },
    confirm: function (el) { window.Motion.replay(el, 'just-selected'); },

    openModal: function (modal) {
      cancelClose(modal);
      modal.classList.remove('is-closing');
      modal.style.display = 'flex';
      var field = modal.querySelector('input:not([type="hidden"]):not([type="checkbox"])');
      if (field) field.focus({ preventScroll: true });
    },

    closeModal: function (modal) {
      if (reduceMotion || modal.style.display === 'none') {
        modal.style.display = 'none';
        return;
      }
      cancelClose(modal);
      function finish() {
        cancelClose(modal);
        modal.classList.remove('is-closing');
        modal.style.display = 'none';
      }
      function onEnd(e) { if (e.target === modal) finish(); }
      modal.classList.add('is-closing');
      modal.addEventListener('animationend', onEnd);
      closing.set(modal, { onEnd: onEnd, timer: setTimeout(finish, 400) });
    }
  };

  // ── Boot ──────────────────────────────────────────────
  var introEnd = choreograph();
  initNav();
  initTabs();
  initNavShadow();
  initToasts();
  initFeedback();
  countUps();
  setTimeout(settle, Math.max(introEnd, SETTLE_MIN_MS));
})();
