from flask import Flask, render_template, request, redirect, url_for, session, flash, g
import sqlite3
import os
import csv
import io
from datetime import datetime, date
from functools import wraps

app = Flask(__name__)
app.secret_key = 'timeslips-secret-key-change-in-production'
DATABASE = 'timeslips.db'

# ── DB Helpers ──────────────────────────────────────────────────────────────

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE, timeout=15)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                full_name TEXT NOT NULL,
                user_code TEXT UNIQUE NOT NULL,
                is_admin INTEGER DEFAULT 0,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS clients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_code TEXT UNIQUE NOT NULL,
                client_name TEXT NOT NULL,
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS activity_codes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                code TEXT UNIQUE NOT NULL,
                description TEXT NOT NULL,
                active INTEGER DEFAULT 1,
                chargeable INTEGER DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                project_code TEXT NOT NULL,
                description TEXT NOT NULL,
                hour_cap REAL,
                active INTEGER DEFAULT 1,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (client_id) REFERENCES clients(id),
                UNIQUE(client_id, project_code)
            );
            CREATE TABLE IF NOT EXISTS client_billing (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                billed_at TEXT DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(client_id, year, month),
                FOREIGN KEY (client_id) REFERENCES clients(id)
            );
            CREATE TABLE IF NOT EXISTS time_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                client_id INTEGER NOT NULL,
                activity_code_id INTEGER NOT NULL,
                entry_date TEXT NOT NULL,
                hours REAL NOT NULL,
                dollar_amount REAL DEFAULT 0,
                is_parts INTEGER DEFAULT 0,
                project_id INTEGER DEFAULT NULL,
                notes TEXT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id),
                FOREIGN KEY (client_id) REFERENCES clients(id),
                FOREIGN KEY (activity_code_id) REFERENCES activity_codes(id)
            );
        ''')
        # Migrate existing DBs — add columns if they don't exist yet
        cols = [r[1] for r in db.execute('PRAGMA table_info(time_entries)').fetchall()]
        if 'dollar_amount' not in cols:
            db.execute('ALTER TABLE time_entries ADD COLUMN dollar_amount REAL DEFAULT 0')
        if 'is_parts' not in cols:
            db.execute('ALTER TABLE time_entries ADD COLUMN is_parts INTEGER DEFAULT 0')
        if 'project_id' not in cols:
            db.execute('ALTER TABLE time_entries ADD COLUMN project_id INTEGER DEFAULT NULL')
        if 'held' not in cols:
            db.execute('ALTER TABLE time_entries ADD COLUMN held INTEGER DEFAULT 0')
        if 'billed' not in cols:
            db.execute('ALTER TABLE time_entries ADD COLUMN billed INTEGER DEFAULT 0')
            db.execute('ALTER TABLE time_entries ADD COLUMN billed_year INTEGER DEFAULT NULL')
            db.execute('ALTER TABLE time_entries ADD COLUMN billed_month INTEGER DEFAULT NULL')
            # One-time backfill: convert the old whole-client-month billed markers
            # into per-entry billed flags, so nothing already billed looks unbilled.
            import calendar as _calendar
            for rec in db.execute('SELECT client_id, year, month FROM client_billing').fetchall():
                bc_last_day = _calendar.monthrange(rec['year'], rec['month'])[1]
                bc_date_from = date(rec['year'], rec['month'], 1).isoformat()
                bc_date_to = date(rec['year'], rec['month'], bc_last_day).isoformat()
                bc_prev_year, bc_prev_month = prev_month(rec['year'], rec['month'])
                bc_prev_last_day = _calendar.monthrange(bc_prev_year, bc_prev_month)[1]
                bc_prev_from = date(bc_prev_year, bc_prev_month, 1).isoformat()
                bc_prev_to = date(bc_prev_year, bc_prev_month, bc_prev_last_day).isoformat()
                db.execute('''
                    UPDATE time_entries
                    SET billed = 1, billed_year = ?, billed_month = ?
                    WHERE client_id = ?
                      AND (
                        (entry_date BETWEEN ? AND ? AND held = 0)
                        OR
                        (entry_date BETWEEN ? AND ? AND held = 1)
                      )
                ''', (rec['year'], rec['month'], rec['client_id'],
                      bc_date_from, bc_date_to, bc_prev_from, bc_prev_to))
        if 'removed_from_report' not in cols:
            db.execute('ALTER TABLE time_entries ADD COLUMN removed_from_report INTEGER DEFAULT 0')
        act_cols = [r[1] for r in db.execute('PRAGMA table_info(activity_codes)').fetchall()]
        if 'chargeable' not in act_cols:
            db.execute('ALTER TABLE activity_codes ADD COLUMN chargeable INTEGER DEFAULT 1')
            # Seed sensible defaults for codes that already exist
            db.execute('''
                UPDATE activity_codes
                SET chargeable = 0
                WHERE UPPER(code) IN ('NB','HOL','SICK','VAC','TRN','DT')
                   OR UPPER(code) LIKE 'ISI-%'
            ''')
        db.commit()
        # Seed admin user if none exists
        existing = db.execute('SELECT id FROM users WHERE username = "admin"').fetchone()
        if not existing:
            db.execute(
                'INSERT INTO users (username, password, full_name, user_code, is_admin) VALUES (?,?,?,?,?)',
                ('admin', 'admin123', 'Administrator', 'ADM', 1)
            )
            db.execute(
                'INSERT INTO clients (client_code, client_name) VALUES (?,?)',
                ('USI', 'Upword Solutions')
            )
            db.execute(
                'INSERT INTO activity_codes (code, description) VALUES (?,?)',
                ('GEN', 'General Support')
            )
            db.commit()

# Run schema migrations at import time, not just when this file is executed
# directly — a production WSGI server (Gunicorn, etc.) imports `app` as a
# module and never hits `if __name__ == '__main__':`, so relying on that
# block alone means migrations silently never run under Gunicorn.
init_db()

# ── Auth Decorators ──────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        if not session.get('is_admin'):
            flash('Admin access required.', 'error')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated

def redirect_admin(tab='users'):
    return redirect(url_for('admin') + f'#tab-{tab}')

# ── Routes ───────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        db = get_db()
        user = db.execute(
            'SELECT * FROM users WHERE username = ? AND password = ?',
            (username, password)
        ).fetchone()
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['full_name'] = user['full_name']
            session['user_code'] = user['user_code']
            session['is_admin'] = bool(user['is_admin'])
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'error')
    return render_template('login.html')

@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    db = get_db()
    today = date.today().isoformat()
    # Recent entries for this user
    entries = db.execute('''
        SELECT te.*, c.client_code, c.client_name, a.code as act_code, a.description as act_desc
        FROM time_entries te
        JOIN clients c ON te.client_id = c.id
        JOIN activity_codes a ON te.activity_code_id = a.id
        WHERE te.user_id = ?
        ORDER BY te.entry_date DESC, te.created_at DESC
        LIMIT 20
    ''', (session['user_id'],)).fetchall()
    # Total hours today
    total = db.execute('''
        SELECT COALESCE(SUM(hours), 0) as total
        FROM time_entries
        WHERE user_id = ? AND entry_date = ?
    ''', (session['user_id'], today)).fetchone()
    return render_template('dashboard.html', entries=entries, today=today,
                           month_total=total['total'])

@app.route('/api/projects/<int:client_id>')
@login_required
def get_projects(client_id):
    from flask import jsonify
    db = get_db()
    projects = db.execute('''
        SELECT p.id, p.project_code, p.description, p.hour_cap,
               COALESCE(SUM(te.hours), 0) as used_hours
        FROM projects p
        LEFT JOIN time_entries te ON te.project_id = p.id
        WHERE p.client_id = ? AND p.active = 1
        GROUP BY p.id
    ''', (client_id,)).fetchall()
    result = []
    for p in projects:
        cap = p['hour_cap']
        used = p['used_hours']
        locked = cap is not None and used >= cap
        result.append({
            'id': p['id'],
            'project_code': p['project_code'],
            'description': p['description'],
            'hour_cap': cap,
            'used_hours': round(used, 2),
            'remaining': round(cap - used, 2) if cap is not None else None,
            'locked': locked
        })
    return jsonify(result)


@app.route('/entry/new', methods=['GET', 'POST'])
@login_required
def new_entry():
    db = get_db()
    if request.method == 'POST':
        # Admins can add an entry on behalf of another user; everyone else
        # can only ever create entries for themselves, regardless of what
        # the form claims.
        for_user_id = session['user_id']
        if session.get('is_admin') and request.form.get('for_user_id'):
            for_user_id = int(request.form['for_user_id'])
        client_id = request.form['client_id']
        activity_id = request.form['activity_code_id']
        entry_date = request.form['entry_date']
        notes = request.form.get('notes', '').strip()
        is_prt = request.form.get('is_prt') == '1'
        errors = []
        if is_prt:
            try:
                dollar_amount = float(request.form.get('dollar_amount', 0))
                if dollar_amount <= 0:
                    errors.append('Dollar amount must be greater than 0.')
                hours = 0.0
            except ValueError:
                errors.append('Dollar amount must be a number.')
                dollar_amount = 0
                hours = 0.0
        else:
            dollar_amount = 0.0
            try:
                hours = float(request.form.get('hours', 0))
                if hours <= 0:
                    errors.append('Hours must be greater than 0.')
            except ValueError:
                errors.append('Hours must be a number.')
        if not entry_date:
            errors.append('Date is required.')
        # Project cap validation
        project_id = request.form.get('project_id') or None
        if project_id and not is_prt:
            proj = db.execute('''
                SELECT p.*, COALESCE(SUM(te.hours),0) as used_hours
                FROM projects p
                LEFT JOIN time_entries te ON te.project_id = p.id
                WHERE p.id = ?
                GROUP BY p.id
            ''', (project_id,)).fetchone()
            if proj and proj['hour_cap'] is not None:
                remaining = proj['hour_cap'] - proj['used_hours']
                if not errors and hours > remaining:
                    errors.append(f'Project {proj["project_code"]} only has {remaining:.2f}h remaining (cap: {proj["hour_cap"]}h). Entry not saved.')
        if errors:
            for e in errors:
                flash(e, 'error')
        else:
            db.execute(
                'INSERT INTO time_entries (user_id, client_id, activity_code_id, entry_date, hours, dollar_amount, is_parts, project_id, notes) VALUES (?,?,?,?,?,?,?,?,?)',
                (for_user_id, client_id, activity_id, entry_date, hours, dollar_amount, 1 if is_prt else 0, project_id, notes)
            )
            db.commit()
            flash('Time entry added successfully.', 'success')
            redirect_kwargs = {'user_id': for_user_id} if for_user_id != session['user_id'] else {}
            return redirect(url_for('new_entry', **redirect_kwargs))

    target_uid = session['user_id']
    if session.get('is_admin') and request.args.get('user_id'):
        target_uid = int(request.args['user_id'])
    target_user = db.execute('SELECT * FROM users WHERE id=?', (target_uid,)).fetchone()
    if not target_user:
        target_uid = session['user_id']
        target_user = db.execute('SELECT * FROM users WHERE id=?', (target_uid,)).fetchone()
    on_behalf = target_uid != session['user_id']

    clients = db.execute('SELECT * FROM clients WHERE active=1 ORDER BY client_code').fetchall()
    activities = db.execute('SELECT * FROM activity_codes WHERE active=1 ORDER BY code').fetchall()
    prt_ids = [str(a['id']) for a in activities if a['code'].upper() == 'PRT']
    today = date.today().isoformat()
    return render_template('new_entry.html', clients=clients, activities=activities,
                           today=today, prt_ids=prt_ids,
                           target_user=target_user, on_behalf=on_behalf)

@app.route('/entry/<int:entry_id>/delete', methods=['POST'])
@login_required
def delete_entry(entry_id):
    db = get_db()
    if session.get('is_admin'):
        entry = db.execute('SELECT * FROM time_entries WHERE id=?', (entry_id,)).fetchone()
    else:
        entry = db.execute('SELECT * FROM time_entries WHERE id=? AND user_id=?',
                           (entry_id, session['user_id'])).fetchone()
    if not entry:
        flash('Entry not found or access denied.', 'error')
    else:
        db.execute('DELETE FROM time_entries WHERE id=?', (entry_id,))
        db.commit()
        flash('Entry deleted.', 'success')
    return redirect(request.referrer or url_for('dashboard'))

@app.route('/entry/<int:entry_id>/edit', methods=['GET', 'POST'])
@login_required
def edit_entry(entry_id):
    db = get_db()
    if session.get('is_admin'):
        entry = db.execute('SELECT * FROM time_entries WHERE id=?', (entry_id,)).fetchone()
    else:
        entry = db.execute('SELECT * FROM time_entries WHERE id=? AND user_id=?',
                           (entry_id, session['user_id'])).fetchone()
    if not entry:
        flash('Entry not found or access denied.', 'error')
        return redirect(url_for('dashboard'))
    next_url = request.form.get('next') or request.referrer or url_for('dashboard')
    if request.method == 'POST':
        client_id = request.form['client_id']
        activity_id = request.form['activity_code_id']
        entry_date = request.form['entry_date']
        notes = request.form.get('notes', '').strip()
        is_prt = request.form.get('is_prt') == '1'
        errors = []
        if is_prt:
            try:
                dollar_amount = float(request.form.get('dollar_amount', 0))
                if dollar_amount <= 0:
                    errors.append('Dollar amount must be greater than 0.')
                hours = 0.0
            except ValueError:
                errors.append('Dollar amount must be a number.')
                dollar_amount = 0
                hours = 0.0
        else:
            dollar_amount = 0.0
            try:
                hours = float(request.form.get('hours', 0))
                if hours <= 0:
                    errors.append('Hours must be greater than 0.')
            except ValueError:
                errors.append('Hours must be a number.')
        if not entry_date:
            errors.append('Date is required.')
        project_id = request.form.get('project_id') or None
        if project_id and not is_prt:
            proj = db.execute('''
                SELECT p.*, COALESCE(SUM(te.hours),0) as used_hours
                FROM projects p
                LEFT JOIN time_entries te ON te.project_id = p.id AND te.id != ?
                WHERE p.id = ?
                GROUP BY p.id
            ''', (entry_id, project_id)).fetchone()
            if proj and proj['hour_cap'] is not None:
                remaining = proj['hour_cap'] - proj['used_hours']
                if not errors and hours > remaining:
                    errors.append(f'Project {proj["project_code"]} only has {remaining:.2f}h remaining (cap: {proj["hour_cap"]}h). Entry not saved.')
        if errors:
            for e in errors:
                flash(e, 'error')
        else:
            db.execute('''
                UPDATE time_entries
                SET client_id=?, activity_code_id=?, entry_date=?, hours=?, dollar_amount=?, is_parts=?, project_id=?, notes=?
                WHERE id=?
            ''', (client_id, activity_id, entry_date, hours, dollar_amount, 1 if is_prt else 0, project_id, notes, entry_id))
            db.commit()
            flash('Entry updated successfully.', 'success')
            return redirect(next_url)
    clients = db.execute('SELECT * FROM clients WHERE active=1 ORDER BY client_code').fetchall()
    activities = db.execute('SELECT * FROM activity_codes WHERE active=1 ORDER BY code').fetchall()
    prt_ids = [str(a['id']) for a in activities if a['code'].upper() == 'PRT']
    # Build pre-fill labels for comboboxes
    client_row = db.execute('SELECT client_code, client_name FROM clients WHERE id=?', (entry['client_id'],)).fetchone()
    activity_row = db.execute('SELECT code, description FROM activity_codes WHERE id=?', (entry['activity_code_id'],)).fetchone()
    client_label = f"{client_row['client_code']} — {client_row['client_name']}" if client_row else ''
    activity_label = f"{activity_row['code']} — {activity_row['description']}" if activity_row else ''
    is_prt = bool(entry['is_parts'])
    prefill_dollars = entry['dollar_amount'] if is_prt else ''
    owner_user = db.execute('SELECT * FROM users WHERE id=?', (entry['user_id'],)).fetchone()
    editing_other = entry['user_id'] != session['user_id']
    return render_template('edit_entry.html', entry=entry, clients=clients, activities=activities,
                           client_label=client_label, activity_label=activity_label,
                           prt_ids=prt_ids, is_prt=is_prt, prefill_dollars=prefill_dollars,
                           owner_user=owner_user, editing_other=editing_other, next_url=next_url)


@app.route('/print', methods=['GET'])
@login_required
def print_slip():
    db = get_db()
    date_from = request.args.get('date_from', date.today().replace(day=1).isoformat())
    date_to = request.args.get('date_to', date.today().isoformat())
    # Admins can view any user; regular users only themselves
    if session.get('is_admin') and request.args.get('user_id'):
        uid = int(request.args.get('user_id'))
    else:
        uid = session['user_id']
    user = db.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()
    entries = db.execute('''
        SELECT te.*, c.client_code, c.client_name, a.code as act_code, a.description as act_desc
        FROM time_entries te
        JOIN clients c ON te.client_id = c.id
        JOIN activity_codes a ON te.activity_code_id = a.id
        WHERE te.user_id = ? AND te.entry_date BETWEEN ? AND ?
        ORDER BY te.entry_date ASC
    ''', (uid, date_from, date_to)).fetchall()
    total_hours = sum(e['hours'] for e in entries)
    all_users = db.execute('SELECT id, full_name, user_code FROM users ORDER BY full_name').fetchall() if session.get('is_admin') else []
    return render_template('print_slip.html', entries=entries, user=user,
                           date_from=date_from, date_to=date_to,
                           total_hours=total_hours, all_users=all_users,
                           selected_uid=uid)

# ── Admin Routes ─────────────────────────────────────────────────────────────

@app.route('/admin')
@admin_required
def admin():
    db = get_db()
    users = db.execute('SELECT * FROM users ORDER BY full_name').fetchall()
    clients = db.execute('SELECT * FROM clients ORDER BY client_code').fetchall()
    activities = db.execute('SELECT * FROM activity_codes ORDER BY code').fetchall()
    # Projects with usage stats per client
    projects = db.execute('''
        SELECT p.*, c.client_code, c.client_name,
               COALESCE(SUM(te.hours), 0) as used_hours
        FROM projects p
        JOIN clients c ON p.client_id = c.id
        LEFT JOIN time_entries te ON te.project_id = p.id
        GROUP BY p.id
        ORDER BY c.client_code, p.project_code
    ''').fetchall()
    return render_template('admin.html', users=users, clients=clients,
                           activities=activities, projects=projects)

@app.route('/admin/user/add', methods=['POST'])
@admin_required
def add_user():
    db = get_db()
    username = request.form['username'].strip()
    password = request.form['password'].strip()
    full_name = request.form['full_name'].strip()
    user_code = request.form['user_code'].strip().upper()
    is_admin = 1 if request.form.get('is_admin') else 0
    try:
        db.execute(
            'INSERT INTO users (username, password, full_name, user_code, is_admin) VALUES (?,?,?,?,?)',
            (username, password, full_name, user_code, is_admin)
        )
        db.commit()
        flash(f'User {full_name} added.', 'success')
    except sqlite3.IntegrityError:
        flash('Username or user code already exists.', 'error')
    return redirect_admin('users')

@app.route('/admin/user/<int:uid>/delete', methods=['POST'])
@admin_required
def delete_user(uid):
    if uid == session['user_id']:
        flash("You can't delete yourself.", 'error')
        return redirect_admin('users')
    db = get_db()
    db.execute('DELETE FROM time_entries WHERE user_id=?', (uid,))
    db.execute('DELETE FROM users WHERE id=?', (uid,))
    db.commit()
    flash('User deleted.', 'success')
    return redirect_admin('users')

@app.route('/admin/client/add', methods=['POST'])
@admin_required
def add_client():
    db = get_db()
    code = request.form['client_code'].strip().upper()
    name = request.form['client_name'].strip()
    try:
        db.execute('INSERT INTO clients (client_code, client_name) VALUES (?,?)', (code, name))
        db.commit()
        flash(f'Client {code} added.', 'success')
    except sqlite3.IntegrityError:
        flash('Client code already exists.', 'error')
    return redirect_admin('clients')

@app.route('/admin/client/<int:cid>/toggle', methods=['POST'])
@admin_required
def toggle_client(cid):
    db = get_db()
    client = db.execute('SELECT * FROM clients WHERE id=?', (cid,)).fetchone()
    db.execute('UPDATE clients SET active=? WHERE id=?', (0 if client['active'] else 1, cid))
    db.commit()
    flash('Client status updated.', 'success')
    return redirect_admin('clients')

@app.route('/admin/client/<int:cid>/delete', methods=['POST'])
@admin_required
def delete_client(cid):
    db = get_db()
    db.execute('DELETE FROM clients WHERE id=?', (cid,))
    db.commit()
    flash('Client deleted.', 'success')
    return redirect_admin('clients')

@app.route('/admin/activity/add', methods=['POST'])
@admin_required
def add_activity():
    db = get_db()
    code = request.form['act_code'].strip().upper()
    desc = request.form['act_desc'].strip()
    chargeable = 1 if request.form.get('chargeable') else 0
    try:
        db.execute('INSERT INTO activity_codes (code, description, chargeable) VALUES (?,?,?)', (code, desc, chargeable))
        db.commit()
        flash(f'Activity {code} added.', 'success')
    except sqlite3.IntegrityError:
        flash('Activity code already exists.', 'error')
    return redirect_admin('activities')

@app.route('/admin/activity/<int:aid>/delete', methods=['POST'])
@admin_required
def delete_activity(aid):
    db = get_db()
    db.execute('DELETE FROM activity_codes WHERE id=?', (aid,))
    db.commit()
    flash('Activity deleted.', 'success')
    return redirect_admin('activities')

@app.route('/admin/activity/<int:aid>/toggle-chargeable', methods=['POST'])
@admin_required
def toggle_activity_chargeable(aid):
    db = get_db()
    activity = db.execute('SELECT * FROM activity_codes WHERE id=?', (aid,)).fetchone()
    db.execute('UPDATE activity_codes SET chargeable=? WHERE id=?', (0 if activity['chargeable'] else 1, aid))
    db.commit()
    flash('Activity chargeable status updated.', 'success')
    return redirect_admin('activities')

# ── Project Routes ────────────────────────────────────────────────────────────

@app.route('/admin/project/add', methods=['POST'])
@admin_required
def add_project():
    db = get_db()
    client_id = request.form['client_id']
    project_code = request.form['project_code'].strip().upper()
    description = request.form['description'].strip()
    hour_cap = request.form.get('hour_cap', '').strip()
    hour_cap = float(hour_cap) if hour_cap else None
    try:
        db.execute(
            'INSERT INTO projects (client_id, project_code, description, hour_cap) VALUES (?,?,?,?)',
            (client_id, project_code, description, hour_cap)
        )
        db.commit()
        flash(f'Project {project_code} added.', 'success')
    except sqlite3.IntegrityError:
        flash('Project code already exists for this client.', 'error')
    return redirect_admin('projects')

@app.route('/admin/project/<int:pid>/toggle', methods=['POST'])
@admin_required
def toggle_project(pid):
    db = get_db()
    p = db.execute('SELECT * FROM projects WHERE id=?', (pid,)).fetchone()
    db.execute('UPDATE projects SET active=? WHERE id=?', (0 if p['active'] else 1, pid))
    db.commit()
    flash('Project status updated.', 'success')
    return redirect_admin('projects')

@app.route('/admin/project/<int:pid>/delete', methods=['POST'])
@admin_required
def delete_project(pid):
    db = get_db()
    db.execute('DELETE FROM projects WHERE id=?', (pid,))
    db.commit()
    flash('Project deleted.', 'success')
    return redirect_admin('projects')

@app.route('/admin/user/<int:uid>/reset-password', methods=['POST'])
@admin_required
def reset_password(uid):
    new_pw = request.form['new_password'].strip()
    if not new_pw:
        flash('Password cannot be empty.', 'error')
        return redirect_admin('users')
    db = get_db()
    db.execute('UPDATE users SET password=? WHERE id=?', (new_pw, uid))
    db.commit()
    flash('Password reset.', 'success')
    return redirect_admin('users')

@app.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current = request.form['current_password']
        new_pw = request.form['new_password'].strip()
        confirm = request.form['confirm_password'].strip()
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE id=?', (session['user_id'],)).fetchone()
        if user['password'] != current:
            flash('Current password is incorrect.', 'error')
        elif new_pw != confirm:
            flash('New passwords do not match.', 'error')
        elif not new_pw:
            flash('Password cannot be empty.', 'error')
        else:
            db.execute('UPDATE users SET password=? WHERE id=?', (new_pw, session['user_id']))
            db.commit()
            flash('Password changed successfully.', 'success')
            return redirect(url_for('dashboard'))
    return render_template('change_password.html')

@app.route('/admin/client/import-csv', methods=['POST'])
@admin_required
def import_clients_csv():
    if 'csv_file' not in request.files:
        flash('No file selected.', 'error')
        return redirect_admin('clients')
    f = request.files['csv_file']
    if f.filename == '' or not f.filename.lower().endswith('.csv'):
        flash('Please upload a valid .csv file.', 'error')
        return redirect_admin('clients')
    db = get_db()
    stream = io.StringIO(f.stream.read().decode('utf-8-sig'))
    reader = csv.DictReader(stream)
    # Normalize headers to lowercase stripped
    reader.fieldnames = [h.strip().lower() for h in (reader.fieldnames or [])]
    added = 0
    skipped = 0
    errors = []
    for i, row in enumerate(reader, start=2):
        code = (row.get('client_code') or row.get('code') or '').strip().upper()
        name = (row.get('client_name') or row.get('name') or '').strip()
        if not code or not name:
            errors.append(f'Row {i}: missing client_code or client_name — skipped.')
            skipped += 1
            continue
        try:
            db.execute('INSERT INTO clients (client_code, client_name) VALUES (?,?)', (code, name))
            added += 1
        except sqlite3.IntegrityError:
            errors.append(f'Row {i}: code "{code}" already exists — skipped.')
            skipped += 1
    db.commit()
    if added:
        flash(f'Imported {added} client(s) successfully.', 'success')
    if skipped:
        flash(f'{skipped} row(s) skipped. ' + ' | '.join(errors), 'error')
    return redirect_admin('clients')


# ── Client Reports ────────────────────────────────────────────────────────────

HOURLY_RATE = 150.00
MONTH_NAMES = ['January','February','March','April','May','June',
               'July','August','September','October','November','December']

def get_month_params():
    import calendar
    today = date.today()
    sel_year = int(request.args.get('year', today.year))
    sel_month = int(request.args.get('month', today.month))
    sel_month = max(1, min(12, sel_month))
    last_day = calendar.monthrange(sel_year, sel_month)[1]
    date_from = date(sel_year, sel_month, 1).isoformat()
    date_to = date(sel_year, sel_month, last_day).isoformat()
    years = [today.year - 1, today.year, today.year + 1]
    return sel_year, sel_month, date_from, date_to, years

def next_month(year, month):
    if month == 12:
        return year + 1, 1
    return year, month + 1

def prev_month(year, month):
    if month == 1:
        return year - 1, 12
    return year, month - 1


@app.route('/reports/clients')
@admin_required
def client_summary_report():
    db = get_db()
    sel_year, sel_month, date_from, date_to, years = get_month_params()
    tab = request.args.get('tab', 'unbilled')

    # Unbilled: every not-yet-billed entry up through the end of the selected
    # month, regardless of which month it was originally logged in — unbilled
    # work rolls forward automatically until it's actually marked billed.
    unbilled_rows = db.execute('''
        SELECT c.id, c.client_code, c.client_name,
               COALESCE(SUM(CASE WHEN te.is_parts=0 THEN te.hours ELSE 0 END), 0) as total_hours,
               COALESCE(SUM(CASE WHEN te.is_parts=1 THEN te.dollar_amount ELSE te.hours * ? END), 0) as total_dollars,
               COUNT(te.id) as entry_count
        FROM clients c
        LEFT JOIN time_entries te ON te.client_id = c.id
        WHERE c.client_code != 'USI'
          AND UPPER(c.client_code) != 'ISI'
          AND te.billed = 0
          AND te.removed_from_report = 0
          AND te.entry_date <= ?
        GROUP BY c.id
        HAVING entry_count > 0
        ORDER BY c.client_code
    ''', (HOURLY_RATE, date_to)).fetchall()

    # Billed: entries that were specifically marked billed during this month's
    # snapshot (either the whole-client bulk action or an individual entry).
    billed_rows_data = db.execute('''
        SELECT c.id, c.client_code, c.client_name,
               COALESCE(SUM(CASE WHEN te.is_parts=0 THEN te.hours ELSE 0 END), 0) as total_hours,
               COALESCE(SUM(CASE WHEN te.is_parts=1 THEN te.dollar_amount ELSE te.hours * ? END), 0) as total_dollars,
               COUNT(te.id) as entry_count
        FROM clients c
        LEFT JOIN time_entries te ON te.client_id = c.id
        WHERE c.client_code != 'USI'
          AND UPPER(c.client_code) != 'ISI'
          AND te.billed = 1
          AND te.removed_from_report = 0
          AND te.billed_year = ?
          AND te.billed_month = ?
        GROUP BY c.id
        HAVING entry_count > 0
        ORDER BY c.client_code
    ''', (HOURLY_RATE, sel_year, sel_month)).fetchall()

    grand_unbilled_hours = sum(r['total_hours'] for r in unbilled_rows)
    grand_unbilled_dollars = sum(r['total_dollars'] for r in unbilled_rows)
    grand_billed_hours = sum(r['total_hours'] for r in billed_rows_data)
    grand_billed_dollars = sum(r['total_dollars'] for r in billed_rows_data)

    return render_template('client_summary_report.html',
                           unbilled_rows=unbilled_rows, billed_rows=billed_rows_data,
                           date_from=date_from, date_to=date_to,
                           grand_unbilled_hours=grand_unbilled_hours,
                           grand_unbilled_dollars=grand_unbilled_dollars,
                           grand_billed_hours=grand_billed_hours,
                           grand_billed_dollars=grand_billed_dollars,
                           rate=HOURLY_RATE, sel_year=sel_year, sel_month=sel_month,
                           month_name=MONTH_NAMES[sel_month-1],
                           years=years, tab=tab)


@app.route('/reports/clients/<int:cid>/mark-billed', methods=['POST'])
@admin_required
def mark_client_billed(cid):
    import calendar
    db = get_db()
    year = int(request.form['year'])
    month = int(request.form['month'])
    date_to = date(year, month, calendar.monthrange(year, month)[1]).isoformat()
    # Snapshot: bill only what's currently outstanding for this client as of
    # this month. Anything logged after this point stays unbilled on its own.
    db.execute('''
        UPDATE time_entries
        SET billed = 1, billed_year = ?, billed_month = ?
        WHERE client_id = ? AND billed = 0 AND entry_date <= ?
    ''', (year, month, cid, date_to))
    db.commit()
    flash('Client marked as billed.', 'success')
    return redirect(url_for('client_summary_report', year=year, month=month, tab='billed'))


@app.route('/reports/clients/<int:cid>/unmark-billed', methods=['POST'])
@admin_required
def unmark_client_billed(cid):
    db = get_db()
    year = int(request.form['year'])
    month = int(request.form['month'])
    db.execute('''
        UPDATE time_entries
        SET billed = 0, billed_year = NULL, billed_month = NULL
        WHERE client_id = ? AND billed = 1 AND billed_year = ? AND billed_month = ?
    ''', (cid, year, month))
    db.commit()
    flash('Client moved back to Unbilled.', 'success')
    return redirect(url_for('client_summary_report', year=year, month=month, tab='unbilled'))


@app.route('/entry/<int:entry_id>/hold', methods=['POST'])
@admin_required
def hold_entry(entry_id):
    db = get_db()
    db.execute('UPDATE time_entries SET held=1 WHERE id=?', (entry_id,))
    db.commit()
    flash('Entry held to next month.', 'success')
    return redirect(request.referrer or url_for('client_summary_report'))


@app.route('/entry/<int:entry_id>/unhold', methods=['POST'])
@admin_required
def unhold_entry(entry_id):
    db = get_db()
    db.execute('UPDATE time_entries SET held=0 WHERE id=?', (entry_id,))
    db.commit()
    flash('Hold removed — entry back in original month.', 'success')
    return redirect(request.referrer or url_for('client_summary_report'))


@app.route('/entry/<int:entry_id>/bill', methods=['POST'])
@admin_required
def bill_entry(entry_id):
    db = get_db()
    year = int(request.form['year'])
    month = int(request.form['month'])
    db.execute('UPDATE time_entries SET billed=1, billed_year=?, billed_month=? WHERE id=?',
               (year, month, entry_id))
    db.commit()
    flash('Entry marked as billed.', 'success')
    return redirect(request.referrer or url_for('client_summary_report'))


@app.route('/entry/<int:entry_id>/unbill', methods=['POST'])
@admin_required
def unbill_entry(entry_id):
    db = get_db()
    db.execute('UPDATE time_entries SET billed=0, billed_year=NULL, billed_month=NULL WHERE id=?',
               (entry_id,))
    db.commit()
    flash('Entry moved back to Unbilled.', 'success')
    return redirect(request.referrer or url_for('client_summary_report'))


@app.route('/entry/<int:entry_id>/remove-from-report', methods=['POST'])
@admin_required
def remove_entry_from_report(entry_id):
    db = get_db()
    db.execute('UPDATE time_entries SET removed_from_report=1 WHERE id=?', (entry_id,))
    db.commit()
    flash('Entry removed from this client\'s report. The employee\'s own hours are unaffected.', 'success')
    return redirect(request.referrer or url_for('client_summary_report'))


@app.route('/entry/<int:entry_id>/restore-to-report', methods=['POST'])
@admin_required
def restore_entry_to_report(entry_id):
    db = get_db()
    db.execute('UPDATE time_entries SET removed_from_report=0 WHERE id=?', (entry_id,))
    db.commit()
    flash('Entry restored to the client report.', 'success')
    return redirect(request.referrer or url_for('client_summary_report'))


@app.route('/reports/clients/<int:cid>')
@admin_required
def client_detail_report(cid):
    db = get_db()
    sel_year, sel_month, date_from, date_to, years = get_month_params()
    client = db.execute('SELECT * FROM clients WHERE id=?', (cid,)).fetchone()
    if not client:
        flash('Client not found.', 'error')
        return redirect(url_for('client_summary_report'))

    # Everything still outstanding for this client as of the end of the
    # selected month — rolls forward automatically until marked billed.
    unbilled_entries = db.execute('''
        SELECT te.*, u.full_name, u.user_code, a.code as act_code, a.description as act_desc
        FROM time_entries te
        JOIN users u ON te.user_id = u.id
        JOIN activity_codes a ON te.activity_code_id = a.id
        WHERE te.client_id = ? AND te.billed = 0 AND te.removed_from_report = 0 AND te.entry_date <= ?
        ORDER BY te.entry_date ASC, u.full_name ASC
    ''', (cid, date_to)).fetchall()

    # Entries that were specifically billed during this month's snapshot
    billed_entries = db.execute('''
        SELECT te.*, u.full_name, u.user_code, a.code as act_code, a.description as act_desc
        FROM time_entries te
        JOIN users u ON te.user_id = u.id
        JOIN activity_codes a ON te.activity_code_id = a.id
        WHERE te.client_id = ? AND te.billed = 1 AND te.removed_from_report = 0
          AND te.billed_year = ? AND te.billed_month = ?
        ORDER BY te.entry_date ASC, u.full_name ASC
    ''', (cid, sel_year, sel_month)).fetchall()

    # Entries removed from this client's report — still exist and still count
    # toward the employee's own hours everywhere else, just hidden from here.
    removed_entries = db.execute('''
        SELECT te.*, u.full_name, u.user_code, a.code as act_code, a.description as act_desc
        FROM time_entries te
        JOIN users u ON te.user_id = u.id
        JOIN activity_codes a ON te.activity_code_id = a.id
        WHERE te.client_id = ? AND te.removed_from_report = 1
        ORDER BY te.entry_date DESC, u.full_name ASC
    ''', (cid,)).fetchall()

    total_hours = sum(e['hours'] for e in unbilled_entries)
    total_dollars = sum(e['dollar_amount'] if e['is_parts'] else e['hours'] * HOURLY_RATE for e in unbilled_entries)
    billed_total_hours = sum(e['hours'] for e in billed_entries)
    billed_total_dollars = sum(e['dollar_amount'] if e['is_parts'] else e['hours'] * HOURLY_RATE for e in billed_entries)
    con_hours_row = db.execute('''
        SELECT COALESCE(SUM(te.hours), 0) as con_hours
        FROM time_entries te
        JOIN activity_codes a ON te.activity_code_id = a.id
        WHERE te.client_id = ? AND te.entry_date BETWEEN ? AND ?
          AND te.held = 0 AND te.removed_from_report = 0 AND UPPER(a.code) = 'CON'
    ''', (cid, date_from, date_to)).fetchone()
    con_hours = con_hours_row['con_hours']
    all_clients = db.execute('''
        SELECT id, client_code, client_name FROM clients
        WHERE client_code != 'USI' AND UPPER(client_code) != 'ISI'
        ORDER BY client_code
    ''').fetchall()
    return render_template('client_detail_report.html',
                           client=client, unbilled_entries=unbilled_entries,
                           billed_entries=billed_entries, removed_entries=removed_entries,
                           date_from=date_from, date_to=date_to,
                           sel_year=sel_year, sel_month=sel_month,
                           month_name=MONTH_NAMES[sel_month-1],
                           total_hours=total_hours, total_dollars=total_dollars,
                           billed_total_hours=billed_total_hours,
                           billed_total_dollars=billed_total_dollars,
                           rate=HOURLY_RATE, all_clients=all_clients,
                           selected_cid=cid, con_hours=con_hours, years=years)


@app.route('/reports/users')
@admin_required
def user_summary_report():
    db = get_db()
    date_from = request.args.get('date_from', date.today().replace(day=1).isoformat())
    date_to = request.args.get('date_to', date.today().isoformat())

    rows = db.execute('''
        SELECT u.id, u.user_code, u.full_name,
               COALESCE(SUM(CASE WHEN te.is_parts=0 THEN te.hours ELSE 0 END), 0) as total_hours,
               COUNT(te.id) as entry_count
        FROM users u
        LEFT JOIN time_entries te ON te.user_id = u.id AND te.entry_date BETWEEN ? AND ?
        GROUP BY u.id
        ORDER BY u.full_name
    ''', (date_from, date_to)).fetchall()

    grand_total_hours = sum(r['total_hours'] for r in rows)
    grand_total_entries = sum(r['entry_count'] for r in rows)
    users_with_hours = sum(1 for r in rows if r['entry_count'] > 0)

    # Chargeable / non-chargeable breakdown by activity code, per user (for print view).
    # USI and ISI are InnovaTek's own internal clients — time logged against them is
    # never chargeable, regardless of the activity code's own chargeable flag.
    activity_rows = db.execute('''
        SELECT te.user_id as uid, a.code as act_code, a.description as act_desc,
               CASE WHEN UPPER(c.client_code) IN ('USI','ISI') THEN 0 ELSE a.chargeable END as is_chargeable,
               COALESCE(SUM(CASE WHEN te.is_parts=0 THEN te.hours ELSE 0 END), 0) as act_hours
        FROM time_entries te
        JOIN activity_codes a ON te.activity_code_id = a.id
        JOIN clients c ON te.client_id = c.id
        WHERE te.entry_date BETWEEN ? AND ?
        GROUP BY te.user_id, a.id, is_chargeable
        HAVING act_hours > 0
        ORDER BY a.code
    ''', (date_from, date_to)).fetchall()

    breakdown = {}
    for r in activity_rows:
        b = breakdown.setdefault(r['uid'], {'chargeable': [], 'non_chargeable': [],
                                             'chargeable_hours': 0.0, 'non_chargeable_hours': 0.0})
        entry = {'code': r['act_code'], 'desc': r['act_desc'], 'hours': r['act_hours']}
        if r['is_chargeable']:
            b['chargeable'].append(entry)
            b['chargeable_hours'] += r['act_hours']
        else:
            b['non_chargeable'].append(entry)
            b['non_chargeable_hours'] += r['act_hours']

    for b in breakdown.values():
        total = b['chargeable_hours'] + b['non_chargeable_hours']
        b['total_hours'] = total
        b['chargeable_dollars'] = b['chargeable_hours'] * HOURLY_RATE
        b['chargeable_pct'] = (b['chargeable_hours'] / total * 100) if total else 0
        b['non_chargeable_pct'] = (b['non_chargeable_hours'] / total * 100) if total else 0
        for entry in b['chargeable'] + b['non_chargeable']:
            entry['pct'] = (entry['hours'] / total * 100) if total else 0

    return render_template('user_summary_report.html',
                           rows=rows, date_from=date_from, date_to=date_to,
                           grand_total_hours=grand_total_hours,
                           grand_total_entries=grand_total_entries,
                           users_with_hours=users_with_hours,
                           breakdown=breakdown, rate=HOURLY_RATE)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
